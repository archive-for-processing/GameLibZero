var img = [];
var st = 0;
backgroundColor = 0;
var nivel = 0;
var fnt;
var puntos = 0;
var idPlayer;
//---------------------------------------------------------------------------------
function preload() {
    img = loadImages("data/images/", 21);
}
//---------------------------------------------------------------------------------
function setup() {
    setMode(640, 400);
    setFps(60);
    //blitter.noSmooth();
    //noSmooth();
}
//---------------------------------------------------------------------------------
function main(){
    switch(st){
        case 0:
            for(var i=0; i<2000; i++){
                var s = new Sprite();
                s.x = random(40, 600);
                s.y = random(40, 360);
                s.graph = img[8];
                s.size = 300;
                s.frame = function(){
                    this.angle++;
                }
            }
            st = 10;
            break;
        case 10:
            screenDrawText(null, 20, sprites.length + " " + int(frameRate()), 4, 320, 10, 255, 255);
            break;
    }
}
//---------------------------------------------------------------------------------
