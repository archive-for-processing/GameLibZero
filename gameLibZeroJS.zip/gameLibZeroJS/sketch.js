var img = [];
var fnt = [];
var st = 0;
backgroundColor = 0;
var puntos = 0;
//---------------------------------------------------------------------------------
function preload() {
    img = loadImages("data/images/", 10);
    fnt[0] = loadFont("data/fonts/NEOTERIC.ttf");
}
//---------------------------------------------------------------------------------
function setup() {
    setMode(640, 400);
    setFps(60);
}
//---------------------------------------------------------------------------------
function main(){
    switch(st){
        case 0:
            
            st = 10;
        break;
        case 10:
            screenDrawText(null, 12, "PROGRAM DEMO BY: LUIS LOPEZ MARTINEZ.", 4, 320, 15, 255, 255);
        break;
    }
}
//---------------------------------------------------------------------------------




