/*
    
    GameLibZeroJS by Luis Lopez Martinez.
       20/06/2018 - Barcelona - Spain.
        License of use: MIT LICENSE.
    
    <<< Video Game Library for P5.js >>>
    
*/

// tipos de cuerpos para la simulación física..
const TYPE_BOX = -1;
const TYPE_CIRCLE = -2;
// materiales disponibles para la simulación física..
const WOOD    = 1;
const METAL   = 2;
const STONE   = 3;
const PLASTIC = 4;
const RUBBER  = 5;
const HUMAN   = 6;

const s_kill  = 7;

var _id_actual_sprite_runing_;      // id del sprite que se esta ejecutando en este momento..

var _app_width_;
var _app_height_;
var _mode_width_;
var _mode_height_;
var blitter;
var fullscreenMode = false;
var backgroundColor = 127;
var _st_app_ = 0;
var mouse;
var sprites = [];
var fps = 60;

var fading = false;
var fadingType = 0;
var deltaFading = 0;
var alphaFading = 255;
var fadingColor = 0;
var idMouse;

// module aliases..
var Engine = Matter.Engine;
var World = Matter.World;
var Bodies = Matter.Bodies;
var Events = Matter.Events;
// create an engine..
var engine = Engine.create();
var world = engine.world;
var glz_collisions = [];
//---------------------------------------------------------------------------------

Events.on(engine, 'collisionEnd', function(event) {
        var pairs = event.pairs;
        for (var i = 0, j = pairs.length; i != j; ++i) {
            var pair = pairs[i];
            if (pair.bodyA == mouse.body) {
                pair.bodyB.render.visible = false;
            } else if (pair.bodyB == mouse.body) {
                pair.bodyA.render.visible = false;
            }
            
            
            
        }
    });


Events.on(engine, 'collisionStart', function(event) {
        var pairs = event.pairs;
        for (var i = 0, j = pairs.length; i != j; ++i) {
            var pair = pairs[i];
            if (pair.bodyA == mouse.body) {
                pair.bodyB.render.visible = true;
            } else if (pair.bodyB == mouse.body) {
                pair.bodyA.render.visible = true;
            }
        }
    });


Events.on(engine, 'collisionActive', function(event) {
        
        var pairs = event.pairs;
        // glz_collisions.splice(0,glz_collisions.length);
        for(var i = 0, j = pairs.length; i != j; ++i) {
            var pair = pairs[i];
            glz_collisions.push(pair);
            if (pair.bodyA === mouse.body) {
                pair.bodyB.render.visible = true;
            } else if (pair.bodyB === mouse.body) {
                pair.bodyA.render.visible = true;
            }
        }
    });


Events.on(world, 'afterAdd', function(event) {
    event.object.render.visible = false;            // al añadir un cuerpo al mundo le pongo la colision con el mouse en false..
    });

//---------------------------------------------------------------------------------
function Scene (){
    this.x = 0;
    this.y = 0;
    this.cameraId;
    this.x0;
    this.x1;
    this.y0;
    this.y1;
    this.delete = function (){
        
    }
    this.add = function (id){
        id.onScene = true;
        id.sceneId = this;
    }
    this.remove = function (id){
        id.onScene = false;
        id.sceneId = null;
    }
    this.setRegion = function (x0, y0, x1, y1){
        this.x0 = x0;
        this.x1 = x1;
        this.y0 = y0;
        this.y1 = y1;
    }
    this.setCamera = function (id){
        this.cameraId = id;
    }
    
    this.camera = function (){
        if(this.cameraId == null){
            return;
        }
        if(this.cameraId.sx > this.x1){
            this.x += this.cameraId.sx - this.x1;
        }
        if(this.cameraId.sx < this.x0){
           this.x -= this.x0 - this.cameraId.sx;
        }
        
        if(this.cameraId.sy > this.y1){
            this.y += this.cameraId.sy - this.y1;
        }
        if(this.cameraId.sy < this.y0){
           this.y -= this.y0 - this.cameraId.sy;
        }
        
    }
    
}
//---------------------------------------------------------------------------------
function draw() {
    switch(_st_app_){
        case 0:
            frameRate(fps);
            mouse = new Mouse();
            for(var i=0; i<256; i++){
                keys.push(false);
            }
            world.gravity.y = 0;
            world.gravity.x = 0;
            _st_app_ = 10;
            break;
        case 10:
            // BACKGROUND CLEAN..
            blitter.background(backgroundColor);
            // MOUSE INTERFACE..
            mouse.frame();
            // MAIN LOOP..
            _id_actual_sprite_runing_ = null;
            main();
            // SORT SPRITE SET..
            sprites.sort(function (a, b) {
                return a.z - b.z;
            });
            
            //Engine.update(engine);                          // physics update step..

            // EXECUTE SPRITE BATCH OPERATIONS..
            for(var i=0; i<sprites.length; i++){
                if (sprites[i].statusKill) {
                    sprites[i].finalize();
                    if(sprites[i].body_created){
                        World.remove(world, sprites[i].body);
                    }
                    sprites.splice(i, 1);        // elimino el sprite de la lista..
                }else if (!sprites[i].live) {
                    sprites[i].statusKill = true;
                }
            }
            
            
            
            for(var i=0; i<sprites.length; i++){
                _id_actual_sprite_runing_ = sprites[i];
                if(_id_actual_sprite_runing_.live){
                    // DRAW SPRITE GRAPH..
                    sprites[i].draw();
                    // EXECUTE SPRITE CODE..
                    sprites[i].frame();
                }
            }
            
            glz_collisions.splice(0,glz_collisions.length);
            Engine.update(engine);                          // physics update step..
            
            
            if (fading) {
                if (fadingType == -1) {
                    if (alphaFading < 255) {
                        alphaFading += deltaFading;
                    } else {
                        deltaFading = 0;
                        alphaFading = 255;
                        fading = false;
                    }
                } else if (fadingType == 1) {
                    if (alphaFading > 0) {
                        alphaFading -= deltaFading;
                    } else {
                        deltaFading = 0;
                        alphaFading = 0;
                        fading = false;
                    }
                }
            }
            
            image(blitter, 0, 0, innerWidth, innerHeight);
            if(alphaFading < 255){
                push();
                    fill(color(0,0,0,255-alphaFading));
                    translate(0,0);
                    rect(0,0,_app_width_, _app_height_);
                pop();
            }
            break;
    }
}
//---------------------------------------------------------------------------------
function fadeOff(time_) {
    fading = true;
    fadingType = 1;
    var fadingFramesLeft = int((time_ * fps) / 1000);
    deltaFading = (255.0 / fadingFramesLeft);
    if(time_ == 0){
        _fade_instantaneo_();
    }
}
//---------------------------------------------------------------------------------
function fadeOn(time_) {
    fading = true;
    fadingType = -1;
    var fadingFramesLeft = int((time_ * fps) / 1000);
    deltaFading = (255.0 / fadingFramesLeft);
    if(time_ == 0){
        _fade_instantaneo_();
    }
}
//---------------------------------------------------------------------------------
function _fade_instantaneo_(){
    if (fadingType == -1) {
        deltaFading = 0;
        alphaFading = 255;
        fading = false;
    } else if (fadingType == 1) {
        deltaFading = 0;
        alphaFading = 0;
        fading = false;
    }
}
//---------------------------------------------------------------------------------
function Mouse() {
    this.x = 0;
    this.y = 0;
    this.left = false;
    this.right = false;
    this.touch = false;
    this.oldX = 0;
    this.oldY = 0;
    this.wheelUp = false;
    this.wheelDown = false;
    this.wheel = 0;
    this.body = Bodies.circle(this.x, this.y, 1);
    this.body.label = "Mouse";
    this.body.isSensor = true;
    this.body.isStatic = true;
    World.add(world, this.body);
    Matter.Body.setStatic(this.body, true);
    //---------------------------------------------------------
    this.frame = function () {
        this.body.force.x = 0;
        this.body.force.y = 0;
        this.left = false;
        this.right = false;
        if (mouseIsPressed){
            if(mouseButton == LEFT){
                this.left = true;
            }
            if(mouseButton == RIGHT){
                this.right = true;
            }
        }
        this.oldX = this.x;
        this.oldY = this.y;
        this.x = mouseX;
        this.y = mouseY;
        //this.body.position.x = this.x = (mouseX * _mode_width_ ) / _app_width_; 
        //this.body.position.y = this.y = (mouseY * _mode_height_) / _app_height_;
        this.x = (mouseX * _mode_width_ ) / _app_width_; 
        this.y = (mouseY * _mode_height_) / _app_height_;
        
        Matter.Body.setPosition(this.body, {x: this.x, y: this.y});
        
    }
    //---------------------------------------------------------
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function Sprite() {
    this.statusKill = false;
    this.visible = true;
    this.graph = null;
    this.x = 0;
    this.y = 0;
    this.z = 512;
    this.angle = 0;
    this.size = 100;
    this.sizeX = 100;
    this.sizeY = 100;
    this.alpha = 255;
    this.xmirror = false;
    this.ymirror = false;
    this.live = true;
    this.killProtection = false;
    sprites.push(this);
    this.body = null;
    this.body_created = false;
    this.id = -1;
    this.father = _id_actual_sprite_runing_;
    this.sceneId;
    this.onScene = false;
    this.sx;
    this.sy;
    this.collisionTypeIds = []; // array de id de los sprites detectados por collisionType()
    //---------------------------------------------------------
    this.draw = function (){        
        if(this.body_created){
            this.x = this.body.position.x;
            this.y = this.body.position.y;            
            this.angle = -degrees(this.body.angle);
        }
        blitter.push();
        blitter.imageMode(CENTER);
        if(this.onScene){
            this.sx = this.x-this.sceneId.x;
            this.sy = this.y-this.sceneId.y;
            blitter.translate(this.sx, this.sy);
        } else{
            blitter.translate(this.x, this.y);
            this.sx = this.x;
            this.sy = this.y;
        }
        
        blitter.rotate(radians(-this.angle));
        if(this.sizeX!=100 || this.sizeY!=100){
            blitter.scale( this.xmirror ? -this.sizeX/100.0 : this.sizeX/100.0, this.ymirror ? -this.sizeY/100.0 : this.sizeY/100.0);
        } else{
            blitter.scale( this.xmirror ? -this.size/100.0 : this.size/100.0, this.ymirror ? -this.size/100.0 : this.size/100.0);
        }
        //blitter.tint(255, this.alpha);
        if(this.visible){
            blitter.image(this.graph, 0, 0);
        }
        blitter.pop();
    }
    //---------------------------------------------------------
    this.frame = function (){
        
    }
    //---------------------------------------------------------
    this.advance = function (dist){
        if(this.body_created){
            let xx = dist * cos(radians(-this.angle));
            let yy = dist * sin(radians(-this.angle));
            Matter.Body.setPosition(this.body, {x: xx+this.body.position.x, y: yy+this.body.position.y});
        }else{
            this.x = this.x + dist * cos(radians(-this.angle));
            this.y = this.y - dist * sin(radians(this.angle));
        }
    }
    //---------------------------------------------------------
    this.advance2 = function(dist, angle){
        if(this.body_created){
            let xx = dist * cos(radians(-angle));
            let yy = dist * sin(radians(-angle));
            Matter.Body.setPosition(this.body, {x: xx+this.body.position.x, y: yy+this.body.position.y});
        }else{
            this.x = this.x + dist * cos(radians(-angle));
            this.y = this.y - dist * sin(radians(angle));
        }
    }
    //---------------------------------------------------------
    this.getAngle = function (x, y){
        var a = degrees(atan2(y-this.y, x-this.x ));
        if(a<0){a=360.0+a;}
        if(a>=360.0){a=0;}  
        return 360-a;
    }
    //---------------------------------------------------------
    this.getAngle2 = function (x1, y1, x2, y2){
        var a = degrees(atan2(y2-y1, x2-x1 ));
        if(a<0){a=360.0+a;}
        if(a>=360.0){a=0;}  
        return 360-a;
    }
    //---------------------------------------------------------
    this.getDist = function (x, y){
        return(dist(this.x, this.y, x, y));
    }
    //---------------------------------------------------------
    this.finalize = function (){
        
    }
    //---------------------------------------------------------
    this.createBody = function (TYPE_BODY){
        var w, h;
        this.body_created = true;
        switch(TYPE_BODY) {
            case TYPE_BOX:
                if(this.sizeX!=100 || this.sizeY!=100 ){
                    w = this.graph.width*(this.sizeX/100.0);
                    h = this.graph.height*(this.sizeY/100.0);
                } else{
                    w = this.graph.width*(this.size/100.0);
                    h = this.graph.height*(this.size/100.0);
                }
                this.body = Bodies.rectangle(this.x, this.y, w, h);
                Matter.Body.setAngle(this.body, radians(-this.angle));
                World.add(engine.world, this.body);
                break;
            case TYPE_CIRCLE:
                w = this.graph.width*this.size/100.0;
                h = this.graph.height*this.size/100.0;
                this.body = Bodies.circle(this.x, this.y, w/2);
                //this.body.angle = radians(this.angle);
                Matter.Body.setAngle(this.body, radians(-this.angle));
                World.add(world, this.body);
                break;
        }
        this.id = this.body.id;
    }
    //---------------------------------------------------------
    this.setMaterial = function (material){
        switch(material) {
            case WOOD:
                this.body.friction = 0.50;
                this.body.restitution = 0.17;
                this.body.density = 0.57;
                break;
            case METAL:
                this.body.friction = 0.13;
                this.body.restitution = 0.17;
                this.body.density = 7.80;
                break;
            case STONE:
                this.body.friction = 0.75;
                this.body.restitution = 0.05;
                this.body.density = 2.40;
                break;
            case PLASTIC:
                this.body.friction = 0.38;
                this.body.restitution = 0.09;
                this.body.density = 0.95;
                break;
            case RUBBER:
                this.body.friction = 0.75;
                this.body.restitution = 0.95;
                this.body.density = 1.70;
                break;
            case HUMAN:
                this.body.friction = 1.00;
                this.body.restitution = 0.00;
                this.body.density = 0.95;
                break;
        }
    }
    //---------------------------------------------------------
    this.setStatic = function (static){
        this.body.isStatic = static;
    }
    //---------------------------------------------------------
    this.setSensor = function (sensor){
        this.body.isSensor = sensor;
    }
    //---------------------------------------------------------
    this.setDamping = function (damping){
        this.body.frictionAir = damping;
    }
    //---------------------------------------------------------
    this.addVx = function (vx){
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x + vx, y: this.body.velocity.y});
    }
    //---------------------------------------------------------
    this.addVy = function (vy){
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x, y: this.body.velocity.y + vy});
    }
    //---------------------------------------------------------
    this.addVelocity = function (angle, vel){
        var vx = vel * cos((radians(angle)));
        var vy = -vel * sin((radians(angle)));
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x + vx, y: this.body.velocity.y + vy});
        
    }
    //---------------------------------------------------------
    this.brakeX = function (percent){
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x * percent, y: this.body.velocity.y});
    }
    //---------------------------------------------------------
    this.brakeY = function (percent){
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x, y: this.body.velocity.y * percent});
    }
    //---------------------------------------------------------
    this.brake = function (percent){
        Matter.Body.setVelocity(this.body, {x: this.body.velocity.x * percent, y: this.body.velocity.y * percent});
    }
    //---------------------------------------------------------
    this.getVelocity = function (){
        return this.body.velocity;
    }
    //---------------------------------------------------------
    this.getVx = function (){
        return this.body.velocity.x;
    }
    //---------------------------------------------------------
    this.getVy = function (){
        return this.body.velocity.y;
    }
    //---------------------------------------------------------
    this.rotate = function (angle){
        Matter.Body.rotate(this.body, radians(-angle));
    }
    //---------------------------------------------------------
    this.setType = function (type){
        this.body.label = type;
    }
    //---------------------------------------------------------
    this.getType = function (type){
        return this.body.label;
    }
    //---------------------------------------------------------
    this.collisionMouse = function (){
        return this.body.render.visible;
    }
    //---------------------------------------------------------
    this.collision = function (other){
        for(var i=0; i<glz_collisions.length; i++){
            
            if( glz_collisions[i].bodyA.id == this.id){
                if( glz_collisions[i].bodyB.id == other.id ){
                   return true;
                }
            } else if(glz_collisions[i].bodyB.id == this.id){
                if( glz_collisions[i].bodyA.id == other.id ){
                   return true;
                }
            }
            
        }
        return false;
    }
    //---------------------------------------------------------
    this.collisionType = function (type){
        
        this.collisionTypeIds.splice(0, this.collisionTypeIds.length);
        
        for(var i=0; i<glz_collisions.length; i++){
            
            if( glz_collisions[i].bodyA.id == this.id){
                if(glz_collisions[i].bodyB.label == type){
                    this.collisionTypeIds.push(glz_collisions[i].bodyB.id);
                }
            } else if(glz_collisions[i].bodyB.id == this.id){
                if(glz_collisions[i].bodyA.label == type ){
                    this.collisionTypeIds.push(glz_collisions[i].bodyA.id);
                   }
            }
            
        }
        console.log(this.collisionTypeIds);
        return this.collisionTypeIds.length;
    }
    //---------------------------------------------------------
    this.getSpriteById = function (id){
        for (var i=0; i<sprites.length; i++) {
            if(sprites[i].id == id){
                if(sprites[i].statusKill == false){
                    return sprites[i];
                }
            }
        }
        return null;
    }
    //---------------------------------------------------------
    this.setAngle = function (angle){
        Matter.Body.setAngle(this.body, radians(-angle));
    }
    //---------------------------------------------------------
    this.translate = function (x, y){
        Matter.Body.setPosition(this.body, {x: x, y: y});
    }
    //---------------------------------------------------------
    this.isContact = function (angA, angB){
        var ang;
        
        for(var i=0; i<glz_collisions.length; i++){             // recorrer la lista de colisiones..
            
            if( glz_collisions[i].bodyA.id == this.id){         // buscar si alguna es mia..
                
                for(var j=0; j<glz_collisions[i].activeContacts.length; j++){
                    ang = this.getAngle(glz_collisions[i].activeContacts[j].vertex.x, glz_collisions[i].activeContacts[j].vertex.y);
                    //console.log(ang);
                    if ( ang > angA && ang < angB ) {
                        return true;
                    }
                }
                
            } else if(glz_collisions[i].bodyB.id == this.id){   // buscar si alguna es mia..
                
                for(var j=0; j<glz_collisions[i].activeContacts.length; j++){
                    ang = this.getAngle(glz_collisions[i].activeContacts[j].vertex.x, glz_collisions[i].activeContacts[j].vertex.y);
                    console.log(ang);
                }
                if ( ang > angA && ang < angB ) {
                        return true;
                }
            }
            
            
                    
        }
        return false;
        
    }
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
    //---------------------------------------------------------
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function signal (id, sig){
    switch(sig){
        case s_kill:
            id.live = false;
        break;
    }
}
//---------------------------------------------------------------------------------
function letMeAlone() {
    for (var i=0; i<sprites.length; i++) {
        if(!sprites[i].killProtection){
            if(sprites[i] != _id_actual_sprite_runing_ ){
                sprites[i].live = false;
            }
        }
    }
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function setMode(width_, height_, fs_) {
    _mode_width_ = width_;
    _mode_height_ = height_;
    _app_width_ = windowWidth;
    _app_height_ = windowHeight;
    createCanvas(windowWidth, windowHeight);
    blitter = createGraphics(width_, height_);
    this.fullscreenMode = fs_;
    
}
//---------------------------------------------------------------------------------
function setFps(fps_){
    fps = fps_;
}
//---------------------------------------------------------------------------------
/* full screening will change the size of the canvas */
function windowResized() {
    _app_width_ = windowWidth;
    _app_height_ = windowHeight;
    resizeCanvas(windowWidth, windowHeight);
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
function screenDrawGraphic(img_, x, y, angle, sizeX, sizeY, alpha) {
    //blitter.resetMatrix();
    blitter.push();
    blitter.imageMode(CENTER);
    //blitter.tint(255, alpha);
    blitter.translate(x, y);
    blitter.rotate(radians(angle));
    blitter.scale(sizeX/100.0, sizeY/100.0);
    blitter.image(img_, 0, 0);
    blitter.pop();
}
//---------------------------------------------------------------------------------
function screenDrawText(fnt_, size, text, cod, x, y, col, alpha) {  
    
    blitter.push();
    if (fnt_ != null) {
        blitter.textFont(fnt_);
    }
    blitter.textSize(size);
    if (cod==4) {
        blitter.textAlign(CENTER, CENTER);
    }
    if (cod==3) {
        blitter.textAlign(LEFT, CENTER);
    }
    if (cod==5) {
        blitter.textAlign(RIGHT, CENTER);
    }
    //blitter.fill(col, alpha);
    blitter.fill(col);
    blitter.text(text, x, y);
    blitter.pop();
}
//---------------------------------------------------------------------------------



//---------------------------------------------------------------------------------
// lista de constantes para las teclas..
// -------------------------------------
const _UP =     38;
const _DOWN =   40;
const _LEFT =   37;
const _RIGHT =  39;
const _SPACE =  32;
const _ESC =    27;
//const _ENTER =  10;
const _ENTER =  13;
const _F1 =     112;
const _F2 =     113;
const _F3 =     114;
const _F4 =     115;
const _F5 =     116;
const _F6 =     117;
const _F7 =     118;
const _F8 =     119;
const _F9 =     120;
const _F10 =    121;
const _PRINT =  154;
const _BLOQ =   145;
const _PAUSE =  19;
const _PLUS  =  139;
const _MINUS =  140;
const _DEL   =  147;
const _A =      65;
const _B =      66;
const _C =      67;
const _D =      68;
const _E =      69;
const _F =      70;
const _G =      71;
const _H =      72;
const _I =      73;
const _J =      74;
const _K =      75;
const _L =      76;
const _M =      77;
const _N =      78;
const _O =      79;
const _P =      80;
const _Q =      81;
const _R =      82;
const _S =      83;
const _T =      84;
const _U =      85;
const _V =      86;
const _W =      87;
const _X =      88;
const _Y =      89;
const _Z =      90;
const _a =      65 + 32;
const _b =      66 + 32;
const _c =      67 + 32;
const _d =      68 + 32;
const _e =      69 + 32;
const _f =      70 + 32;
const _g =      71 + 32;
const _h =      72 + 32;
const _i =      73 + 32;
const _j =      74 + 32;
const _k =      75 + 32;
const _l =      76 + 32;
const _m =      77 + 32;
const _n =      78 + 32;
const _o =      79 + 32;
const _p =      80 + 32;
const _q =      81 + 32;
const _r =      82 + 32;
const _s =      83 + 32;
const _t =      84 + 32;
const _u =      85 + 32;
const _v =      86 + 32;
const _w =      87 + 32;
const _x =      88 + 32;
const _y =      89 + 32;
const _z =      90 + 32;
const num_keys_ = 256;
var keys = [num_keys_];
//---------------------------------------------------------------------------------

function keyPressed() {
    keys[keyCode] = true;
    if (keyCode == 27) {
        key = 0;
    }
}
//---------------------------------------------------------------------------------
function keyReleased() {
    keys[keyCode] = false;
}
//---------------------------------------------------------------------------------
function tecla(code) {
    return keys[code];
}
//---------------------------------------------------------------------------------
function loadImages (path, num){
    var images = [];
    var name;
    for(var i=0; i<=num; i++){
        if(i < 10){
            name = "0" + str(i) + ".png";
        } else{
            name = str(i) + ".png";
        }
        images[i] = loadImage(path+name, );
    }   
    return images;
}
//---------------------------------------------------------------------------------
function method (codeToExecute){
    var tmpFunc = new Function(codeToExecute);
    tmpFunc();
}
//---------------------------------------------------------------------------------
function newGraph(w, h, col) {
    var gr = createImage(w, h);
    gr.loadPixels();
    for (var i = 0; i < gr.pixels.length; i++) {
        gr.pixels[i] = col;
    }
    gr.updatePixels();
    return gr;
}
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------




