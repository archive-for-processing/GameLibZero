var img = [];
var fnt = [];
var snd = [];
var sonic = [];
var st = -10;
backgroundColor = 0;
var escena;
var p;
var lv = 0;
//---------------------------------------------------------------------------------
function preload() {
    img = loadImages("data/images/", 8);
    sonic = loadImages("data/images/sonic/", 24);
}
//---------------------------------------------------------------------------------
function setup() {
    setMode(640, 400);
    setFps(60);
    blitter.noSmooth();
    noSmooth();
}
//---------------------------------------------------------------------------------
function main(){
    
    switch(st){
        case -10:
            fadeOff(0);
            st = -5;
            break;
        case -5:
            if(!fading){
                escena = new Scene();
                escena.setRegion(200, 0, 440, 400);
                st = 0;
            }
            break;
        case 0:
            switch(lv){     // select level launcher..
                case 0:     // level 0..
                    character();
                    platform(img[8], 120, 380);
                    platform(img[8], 320, 380);
                    platform(img[8], 520, 380);
                    platform(img[8], 800, 280);
                    platform(img[8], 1000, 180);
                    object01(1100, 150);
                    break;
                case 1:     // level 1..
                    character();
                    platform(img[8], 120, 380);
                    platform(img[8], 320, 280);
                    platform(img[8], 520, 380);
                    platform(img[8], 800, 280);
                    platform(img[8], 1000, 180);
                    object01(800, 150);
                    break;
                case 2:
                    fin_del_juego();
                    break;
            }
            fadeOn(1500);
            st = 10;
        break;
        case 10:
            if(lv<2){
                screenDrawText(null, 22, "LEVEL " + lv, 4, 320, 20, 255, 255);
                escena.camera();
            }
        break;
        case 20:
            // escena completed..
            fadeOff(2000);
            st = 30;
            break;
        case 30:
            if(!fading){
                letMeAlone();   // eliminar sprites..
                escena = null;
                lv++;           // aumentar 1 nivel..
                st = 40;
            }
            break;
        case 40:
            st = -5;
            break;
    }
}
//---------------------------------------------------------------------------------
function character(){
    p = new Sprite();
    p.graph = sonic[0];
    p.x = 320;
    p.y = 200;
    p.size = 200;
    p.vel = 0.5;
    p.animaLeft = 0;
    p.animaStepLeft = 0;
    p.animaRight = 0;
    p.animaStepRight = 0;
    p.animaStepBall = 0;
    p.animaWalk = [2,2,2,2,2,3,3,3,3,3,4,4,4,4,4];
    p.animaRun  = [5,5,5,5,5,6,6,6,6,6,7,7,7,7,7];
    p.animaBrake= [8,8,8,8,8,8,8,8,8,8,8,8,8,8,8];
    p.animaBall = [9,9,9,9,9,10,10,10,10,10,11,11,11,11];
    p.floor_contact = false;
    p.jumping = 0;
    p.createBody(TYPE_CIRCLE);
    p.body.friction = 0;
    //p.setMaterial(HUMAN);
    
    escena.add(p);
    escena.setCamera(p);
    p.locked = false;
    p.frame = function (){
        if(this.locked){
            return;
        }
        // check is touching floor..
        this.floor_contact = this.isContact(225, 315);
        
        // stand animation..
        this.setAngle(0);
        this.graph = sonic[0];
        
        // down animation..
        if(tecla(_DOWN)){
            this.graph = sonic[1];
        }
        
        // left movement & left animation..
        if(tecla(_LEFT)){
            if(this.getVx() > -5){
                this.addVx(-this.vel);
            }
            // ANIMATION SEQUENCE..
            this.animaLeft = (this.animaLeft + 1) % this.animaWalk.length;
            // ANIMATION STEP..
            if(this.animaLeft == 0){
                this.animaStepLeft = 1;
            }
            // ANIMATIONS TYPE..
            if(this.getVx() < 0.1){
                this.xmirror = true;
                if(this.animaStepLeft == 0){
                    this.graph = sonic[this.animaWalk[this.animaLeft]];
                } else {
                    this.graph = sonic[this.animaRun[this.animaLeft]];
                }
            } else{
                this.xmirror = false;
                this.graph = sonic[this.animaBrake[this.animaLeft]];
            }
        } else{
                this.animaStepLeft = 0;
                this.animaLeft = 0;
        }
        
        
        // right movement & right animation..
        if(tecla(_RIGHT)){
            if(this.getVx() < 5){
                this.addVx(this.vel);
            }
            // ANIMATION SEQUENCE..
            this.animaRight = (this.animaRight + 1) % this.animaWalk.length;
            // ANIMATION STEP..
            if(this.animaRight == 0){
                this.animaStepRight = 1;
            }
            // ANIMATIONS TYPE..
            if(this.getVx() > 0.1){
                this.xmirror = false;
                if(this.animaStepRight == 0){
                    this.graph = sonic[this.animaWalk[this.animaRight]];
                } else {
                    this.graph = sonic[this.animaRun[this.animaRight]];
                }
            } else{
                this.xmirror = true;
                this.graph = sonic[this.animaBrake[this.animaRight]];
            }
        } else{
                this.animaStepRight = 0;
                this.animaRight = 0;
        }
        
        if(!tecla(_LEFT) && !tecla(_RIGHT)){
           this.brakeX(0.8);
            
        }
        
        // jump sequence..
        switch(this.jumping){
            case 0:
                if(tecla(_SPACE) && this.floor_contact){
                    this.addVy(-10);
                    this.jumping = 10;
                }
                break;
            case 10:
                this.animaStepBall = (this.animaStepBall + 1) % this.animaBall.length;
                this.graph = sonic[this.animaBall[this.animaStepBall]];
                if(this.floor_contact){
                    this.jumping = 0;
                }
                break;
        }
        
        // private gravity..
        this.body.force.y += 0.002;
    }
}
//---------------------------------------------------------------------------------
function platform(graph, x, y){
    var s = new Sprite();
    s.graph = graph;
    s.x = x;
    s.y = y;
    s.createBody(TYPE_BOX);
    s.setStatic(true);
    escena.add(s);
}
//---------------------------------------------------------------------------------
function object01(x, y){
    var s = new Sprite();
    s.graph = img[0];
    s.x = x;
    s.y = y;
    s.createBody(TYPE_CIRCLE);
    s.setSensor(true);
    s.flag = false;
    escena.add(s);
    s.frame = function (){
        if(!this.flag){
            if(this.collision(p)){
                st = 20;                // level completed!!
                p.locked = true;        // lock player..
                p.brake(0.2);
                this.flag = true;
            }
        }
    }
    
}
//---------------------------------------------------------------------------------
function fin_del_juego(){
    var s = new Sprite();
    s.visible = false;
    s.frame = function (){
        screenDrawText(null, 64, "GAME OVER", 4, 320, 120, 255, 255);
    }
}
//---------------------------------------------------------------------------------


















